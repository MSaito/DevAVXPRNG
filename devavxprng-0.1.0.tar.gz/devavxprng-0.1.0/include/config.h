/* include/config.h.  Generated from config.h.in by configure.  */
/* include/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if compiler can use -mavx2 */
#define HAVE_AVX2 0

/* Define to 1 if compiler can use -mavx512f */
#define HAVE_AVX512F 0

/* Define to 1 if you have __builtin_cpu_supports function */
#define HAVE_BUILTIN_CPU_SUPPORTS 1

/* Define to 1 if you have __builtin_parityll function */
#define HAVE_BUILTIN_PARITYLL 1

/* Define to 1 if you have the <cpuid.h> header file. */
#define HAVE_CPUID_H 1

/* define if the compiler supports basic C++11 syntax */
#define HAVE_CXX11 1

/* define if the compiler supports basic C++14 syntax */
#define HAVE_CXX14 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <getopt.h> header file. */
#define HAVE_GETOPT_H 1

/* Define to 1 if you have the <immintrin.h> header file. */
#define HAVE_IMMINTRIN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `gf2x' library (-lgf2x). */
#define HAVE_LIBGF2X 1

/* Define to 1 if you have the `gmp' library (-lgmp). */
#define HAVE_LIBGMP 1

/* Define to 1 if you have the `MTToolBox' library (-lMTToolBox). */
#define HAVE_LIBMTTOOLBOX 1

/* Define to 1 if you have the `ntl' library (-lntl). */
#define HAVE_LIBNTL 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have _may_i_use_cpu_feature function */
#define HAVE_MAY_I_USE_CPU_FEATURE 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if compiler can use -msse2 */
#define HAVE_SSE2 1

/* Define to 1 if compiler can use -msse4.1 */
#define HAVE_SSE4_1 1

/* Define to 1 if compiler can use -msse4.2 */
#define HAVE_SSE4_2 1

/* Define to 1 if compiler can use -mssse3 */
#define HAVE_SSSE3 1

/* Define if g++ supports C++0x features. */
#define HAVE_STDCXX_0X /**/

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have std::shared_ptr */
#define HAVE_STD_SP 1

/* Define to 1 if you have std::tr1::shared_ptr */
#define HAVE_STD_TR1_SP 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the <x86intrin.h> header file. */
#define HAVE_X86INTRIN_H 1

/* Define to 1 if you have the <zmmintrin.h> header file. */
/* #undef HAVE_ZMMINTRIN_H */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "devavxprng"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "saito@manieth.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "DevAVXPRNG"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "DevAVXPRNG 0.1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "devavxprng"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.1.0"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "0.1.0"

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Define to the type of a signed integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int64_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */
